package com.cigna.userexit.oktasso;

public class TestOktaApi {

    public static void main(String args[]) {
        try {
            ValidateInOkta.getUser("dev-123456.okta.com", "00a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t", "devuser@cignadev.com","test1234");
        } catch (Exception e) {
            System.err.println("Exception when calling ValidateInOkta.getUser");
        }
    }
}

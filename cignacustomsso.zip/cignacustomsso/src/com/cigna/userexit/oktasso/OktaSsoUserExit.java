package com.cigna.userexit.oktasso;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import EDU.oswego.cs.dl.util.concurrent.SynchronizedLong;
import com.sterlingcommerce.hadrian.api.SEASCustomExitInterface;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openapitools.client.model.User;

public class OktaSsoUserExit implements SEASCustomExitInterface {
    public static final String PROPKEY_UserIdExistsInOkta = "UserIdExistsInOkta";
    //public static final String PROPKEY_UserIdIsSubjectCN = "UserIdIsSubjectCN";
    public static final String PROPKEY_RunDfltAuthenticatorWhenDone = "RunDfltAuthenticator";
    static private SynchronizedLong passCounter = new SynchronizedLong(0);
    static private SynchronizedLong failCounter = new SynchronizedLong(0);
    public static final String OUTPUTKEY_PASSCOUNT = "passcount";
    public static final String OUTPUTKEY_FAILCOUNT = "failcount";
    private Properties customProps;
    private CertificateFactory certFactory;
    private String profile;
    public static final String PWD = "pwd";  //MFT-10352
    public static final String PASSPHRASE = "passphrase"; //MFT-10352
    private static Logger log = LogManager.getLogger(OktaSsoUserExit.class);
    public static final String PROPKEY_MappedUid = "mappedUid";
    public static final String PROPKEY_MappedPwd = "mappedPwd";

    public static final String PROPKEY_OktaApiUrl = "OktaApiUrl";
    public static final String PROPKEY_OktaApiToken = "OktaApiToken";
    public OktaSsoUserExit() {
        super();
        System.out.println(this.getClass().getName() + " instantiated");
    }

    public boolean processRequest(Map<String,Object> request, List<String> logs)
            throws Exception
    {
        boolean runDfltAuthenticatorWhenDone = false;
        Exception eReturn = null;
        long passCount =  passCounter.get();
        long failCount =  failCounter.get();

        try {           // SEAS-665 - using new local variable
            processRequestWorker(request, logs, runDfltAuthenticatorWhenDone);
            passCount = passCounter.increment();
        }
        catch (Exception e) {
            failCount = failCounter.increment();
            eReturn = e;
        }
        Properties exitOutputs = new Properties();
        exitOutputs.setProperty(OUTPUTKEY_PASSCOUNT, Long.toString(passCount));
        exitOutputs.setProperty(OUTPUTKEY_FAILCOUNT, Long.toString(failCount));
        request.put(SEASCustomExitInterface.REQKEY_EXITOUTPUTS, exitOutputs);
        if (eReturn != null) {
            throw eReturn;
        }
        return runDfltAuthenticatorWhenDone;
    }

    public void initialize(String profile, Properties customProps)
            throws Exception
    {
        this.profile = profile;		// Name of this CustomExit instance.

        System.out.println(this.getClass().getName()
                + " initializing -- profile = " + profile);
        if (customProps == null) {
            customProps = new Properties();
        }

        this.customProps = customProps;

        certFactory = CertificateFactory.getInstance("X.509");
        // SEAS-665 - Moved code from here to processRequestWorker method
        //            so it uses local and unique variables.
    }

    /* (non-Javadoc)
     * @see com.sterlingcommerce.hadrian.api.SEASCustomExitInterface#terminate()
     */
    public void terminate() throws Exception
    {
        System.out.println(this.getClass().getName()
                + " terminating -- profile = " + profile);
        // Do any cleanup required to terminate this exit instance
    }

    @SuppressWarnings("rawtypes")
    private void dumpCustomProps()
    {
        // MFT-10352, if key contains password, pwd or passphrase, then don't print
        // the value
        if (this.customProps != null) {
            Iterator iter = customProps.keySet().iterator();
            while (iter.hasNext()) {
                String key = (String) iter.next();
                String tmpKey = key;
                if (!tmpKey.toLowerCase().contains(SEASCustomExitInterface.REQKEY_PASSWORD)
                        && !tmpKey.toLowerCase().contains(PWD) && !tmpKey.toLowerCase().contains(PASSPHRASE)) {
                    System.out.println("key = " + key + ", value : " + customProps.get(key));
                }
            }
        }
    }

    @SuppressWarnings("rawtypes")
    // SEAS-665 - using new local variable
    private void processRequestWorker(Map<String,Object> request, List<String> logs, boolean runDfltAuthenticatorWhenDone)
            throws Exception
    {

        // SEAS-665 - Moved following 4 global variables from start of class
        //            to here so they are local and unique.
        boolean verifyUserIdExistsInOkta = true;
        boolean verifyUserIdIsSubjectCN = false;
        String mappedUid = null;
        String mappedPwd = null;

        System.out.println(this.getClass().getName() + " received an Authentication Request:");

        // SEAS-665 - Moved following code from initialize() method to here
        //            so it uses local and unique variables.
        // Process the initialization properties
        if(customProps != null) {
            String val = customProps.getProperty(PROPKEY_RunDfltAuthenticatorWhenDone);
            if (val != null) {
                runDfltAuthenticatorWhenDone = Boolean.parseBoolean(val);
            }
            val = customProps.getProperty(PROPKEY_UserIdExistsInOkta);
            if (val != null) {
                verifyUserIdExistsInOkta = Boolean.parseBoolean(val);
            }
            /*val = customProps.getProperty(PROPKEY_UserIdIsSubjectCN);
            if (val != null) {
                verifyUserIdIsSubjectCN = Boolean.parseBoolean(val);
            }*/
            mappedUid = customProps.getProperty(PROPKEY_MappedUid);
            mappedPwd = customProps.getProperty(PROPKEY_MappedPwd);

            //System.out.println("Verify user ID is password = " + verifyUserIdIsPassword);
            System.out.println("Verify user ID is subject CN = " + verifyUserIdIsSubjectCN);
            System.out.println("Run default authenticator when done = " + runDfltAuthenticatorWhenDone);
            System.out.println("MappedUid = " + mappedUid);
        }
        // SEAS-665 - End of moved code

        String userId = (String)request.get(SEASCustomExitInterface.REQKEY_USERID);
        System.out.println("User ID = " + userId);
        System.out.println("Profile = " + profile);
        System.out.println("Client ID = " + request.get(SEASCustomExitInterface.REQKEY_CLIENTID));
        System.out.println("Correlator = " + request.get(SEASCustomExitInterface.REQKEY_CORRELATOR));

        if(log.isDebugEnabled()) { // MFT-10352
            dumpCustomProps();
        }


        if (verifyUserIdExistsInOkta) {      // SEAS-665 - using local variable
            System.out.println("Verifying user ID and password are the same.");
            char[] password = null;

            Object o = request.get(SEASCustomExitInterface.REQKEY_PASSWORD);
            if(o != null && o instanceof char[]) {
                password = (char[])o;
            }else {
                if(o != null) {
                    String strPwd = (String)o;
                    password = strPwd.toCharArray();
                }
            }

            if (userId == null) {
                throw new Exception("The user ID cannot be null.");
            }
            if (password == null) {
                throw new Exception("The password cannot be null.");
            }

            String OktaApiUrl = customProps.getProperty(PROPKEY_OktaApiUrl);
            String OktaApiToken = customProps.getProperty(PROPKEY_OktaApiToken);
            User user = ValidateInOkta.getUser(OktaApiUrl, OktaApiToken, userId, new String(password));
            if (user == null) {
                throw new Exception("The user ID is not valid: " + userId);
            }

            password = null; //SEAS-693
            String message = "Verified user ID (" + userId + ") and user exists in Okta.";
            System.out.println(message);
            logs.add(message);
            return;
        }

        throw new Exception("The user ID is not valid: " + userId);

    }

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

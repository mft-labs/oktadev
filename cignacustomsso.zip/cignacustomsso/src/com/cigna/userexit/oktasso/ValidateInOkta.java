package com.cigna.userexit.oktasso;

import com.okta.sdk.authc.credentials.TokenClientCredentials;

import com.okta.sdk.client.Clients;
import com.okta.sdk.resource.user.UserBuilder;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.api.UserApi;
import org.openapitools.client.model.User;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;


import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.*;
import java.security.cert.*;

import java.security.cert.Certificate;
public class ValidateInOkta {

        public static User getUser(String oktaDomain, String apiToken, String userId, String passwd) throws Exception {
            // Instantiate a builder for your Client. If needed, settings like Proxy and Caching can be defined here.
            try {

                // Create a trust manager that does not validate certificate chains
                Certificate cert = getCertificateFromServer("https://"+oktaDomain);

                // 2. Store the certificate in a Java KeyStore
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(null, null);  // Initialize an empty KeyStore
                ks.setCertificateEntry("serverCert", cert);  // Add the server's certificate

                // 3. Create an SSLContext and use the KeyStore as a trust store
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(ks);  // Initialize the TrustManagerFactory with the KeyStore

                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());  // Initialize the SSLContext with the TrustManagerFactory
                SSLContext.setDefault( sslContext );
                ApiClient client = Clients.builder()
                        .setOrgUrl("https://"+oktaDomain)  // e.g. https://dev-123456.okta.com
                        .setClientCredentials(new TokenClientCredentials(apiToken))
                        .build();


                UserApi userApi = new UserApi(client);
                try {
                    User user = userApi.getUser(userId);
                    if (user.getCredentials().getPassword().getValue().equalsIgnoreCase(passwd)) {
                        System.out.println("User: " + user.getProfile().getLogin());
                        return user;
                    } else {
                        throw new Exception("The user ID is not valid: "+userId+ " "+oktaDomain+ " Invalid credentials" );
                    }

                } catch (ApiException e) {
                    System.err.println("Exception when calling UserApi#getUser");
                    throw new Exception("The user ID is not valid: "+userId+ " "+oktaDomain+ " " + e.getMessage());

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

    private static Certificate getCertificateFromServer(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.connect();

        Certificate[] certs = conn.getServerCertificates();  // Get the server's certificate chain
        return certs[0];  // Return the server's certificate
    }

}
